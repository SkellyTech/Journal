//============================================================================
// Name        : HashTable.cpp
// Author      : John Watson
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string> // atoi
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

struct Bid {
    string bidId; // Unique identifier for the bid
    string title;
    string fund;
    double amount;

    Bid() : amount(0.0) {}
};

struct Node {
    Bid bid;               // Stores the bid
    unsigned key;          // Hash key
    Node* nextNodePtr;     // Pointer to the next node

    Node() {
        key = UINT_MAX;
        nextNodePtr = nullptr;
    }

    Node(Bid myBid) : Node() {
        bid = myBid;
    }

    Node(Bid myBid, unsigned newKey) : Node(myBid) {
        key = newKey;
    }
};

class HashTable {
private:
    vector<Node*> table; // Vector of Node pointers
    int capacity;        // Total capacity of the hash table
    int size;            // Current number of elements

    // Hash function
    unsigned hash(const string& key) const {
        unsigned hashValue = 0;
        for (char ch : key) {
            hashValue = hashValue * 31 + ch;
        }
        return hashValue % capacity;
    }

public:
    // Constructor
    HashTable(int cap) : capacity(cap), size(0) {
        table.resize(capacity, nullptr);
    }

    // Destructor
    ~HashTable() {
        clear();
    }

    // Insert a bid
    void insert(Bid bid) {
        unsigned key = hash(bid.bidId);
        Node* newNode = new Node(bid, key);

        if (table[key] == nullptr) {
            table[key] = newNode;
        }
        else {
            Node* temp = table[key];
            while (temp->nextNodePtr != nullptr) {
                temp = temp->nextNodePtr;
            }
            temp->nextNodePtr = newNode;
        }
        size++;
    }

    // Search for a bid by ID
    Bid search(const string& bidId) const {
        unsigned key = hash(bidId);
        Node* temp = table[key];

        while (temp != nullptr) {
            if (temp->bid.bidId == bidId) {
                return temp->bid;
            }
            temp = temp->nextNodePtr;
        }

        return Bid(); // Return an empty Bid if not found
    }

    // Remove a bid by ID
    bool remove(const string& bidId) {
        unsigned key = hash(bidId);
        Node* temp = table[key];
        Node* prev = nullptr;

        while (temp != nullptr && temp->bid.bidId != bidId) {
            prev = temp;
            temp = temp->nextNodePtr;
        }

        if (temp == nullptr) {
            return false; // Not found
        }

        if (prev == nullptr) {
            table[key] = temp->nextNodePtr;
        }
        else {
            prev->nextNodePtr = temp->nextNodePtr;
        }

        delete temp;
        size--;
        return true;
    }

    // Display the hash table
    void display() const {
        for (int i = 0; i < capacity; ++i) {
            cout << "Bucket " << i << ": ";
            Node* temp = table[i];
            while (temp != nullptr) {
                cout << "(" << temp->bid.bidId << ", " << temp->bid.title << ", " << temp->bid.amount << ") ";
                temp = temp->nextNodePtr;
            }
            cout << endl;
        }
    }

    // Clear the hash table
    void clear() {
        for (Node* bucket : table) {
            while (bucket != nullptr) {
                Node* temp = bucket;
                bucket = bucket->nextNodePtr;
                delete temp;
            }
        }
        table.clear();
        size = 0;
    }

    // Get the current size of the hash table
    int getSize() const {
        return size;
    }

    // Check if the hash table is empty
    bool isEmpty() const {
        return size == 0;
    }
};

int main() {
    HashTable hashTable(10);

    Bid bid1 = { "1", "Bid One", "Fund A", 100.50 };
    Bid bid2 = { "2", "Bid Two", "Fund B", 200.75 };
    Bid bid3 = { "3", "Bid Three", "Fund C", 300.25 };

    hashTable.insert(bid1);
    hashTable.insert(bid2);
    hashTable.insert(bid3);

    cout << "Initial table:" << endl;
    hashTable.display();

    cout << "Search for Bid ID '2':" << endl;
    Bid foundBid = hashTable.search("2");
    if (!foundBid.bidId.empty()) {
        cout << "Found: " << foundBid.title << " ($" << foundBid.amount << ")" << endl;
    }
    else {
        cout << "Bid not found" << endl;
    }

    hashTable.remove("2");
    cout << "After removing Bid ID '2':" << endl;
    hashTable.display();

    return 0;
}

