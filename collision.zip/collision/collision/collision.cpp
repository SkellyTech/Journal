#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

const float DEG2RAD = 3.14159 / 180;

enum BRICKTYPE { DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick {
public:
    float red, green, blue;
    float x, y, width;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int hits;

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb) {
        brick_type = bt; x = xx; y = yy; width = ww; red = rr, green = gg, blue = bb;
        onoff = ON;
        hits = 0;
    };

    void drawBrick() {
        if (onoff == ON) {
            double halfside = width / 2;

            glColor3d(red, green, blue);
            glBegin(GL_POLYGON);

            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);

            glEnd();
        }
    }

    void handleCollision() {
        if (brick_type == DESTRUCTABLE) {
            hits++;
            if (hits >= 1) {
                onoff = OFF;
            }
        }
    }
};

class Circle {
public:
    float red, green, blue;
    float radius;
    float x;
    float y;
    float speed = 0.03;
    float angle;

    Circle(double xx, double yy, double rr, float rad, float r, float g, float b) {
        x = xx;
        y = yy;
        radius = rr;
        red = r;
        green = g;
        blue = b;
        radius = rad;
        angle = static_cast<float>(rand() % 360);
    }

    void CheckCollision(Brick* brk) {
        if ((x > brk->x - brk->width && x <= brk->x + brk->width) &&
            (y > brk->y - brk->width && y <= brk->y + brk->width)) {
            brk->handleCollision();
            angle = 180 - angle;
        }
    }

    void CheckCollision(Circle& otherCircle) {
        float distance = sqrt(pow(x - otherCircle.x, 2) + pow(y - otherCircle.y, 2));
        float combinedRadius = radius + otherCircle.radius;

        if (distance < combinedRadius) {
            // Handle circle-circle collision here
            // You can implement the desired options like combining, changing color, disappearing, or spawning smaller circles
            // For simplicity, let's make both circles disappear upon collision
            x = y = 2.0; // Move the circle off-screen to make it "disappear"
            otherCircle.x = otherCircle.y = 2.0; // Move the other circle off-screen
        }
    }

    void MoveOneStep() {
        x += speed * cos(angle * DEG2RAD);
        y += speed * sin(angle * DEG2RAD);

        if (x - radius < -1 || x + radius > 1) {
            angle = 180 - angle;
        }

        if (y - radius < -1 || y + radius > 1) {
            angle = -angle;
        }
    }

    void DrawCircle() {
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float degInRad = i * DEG2RAD;
            glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
        }
        glEnd();
    }

    void handleCollision(Circle& otherCircle) {
        // Add collision handling logic if needed
    }
};

vector<Circle> world;
vector<Brick> bricks;

Brick paddle(DESTRUCTABLE, 0, -0.95, 0.2, 0.5, 0.5, 0.5);

void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    double xpos, ypos;
    glfwGetCursorPos(window, &xpos, &ypos);
    paddle.x = static_cast<float>(xpos / 240) - 1.0;

    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        for (int i = 0; i < 10; ++i) {
            double r, g, b;
            r = rand() / 10000;
            g = rand() / 10000;
            b = rand() / 10000;
            Circle B(0, 0, 0.2, 0.05, r, g, b);
            world.push_back(B);
        }
    }
}

int main(void) {
    srand(time(NULL));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(480, 480, "Random World of Circles", NULL, NULL);

    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    bricks.push_back(Brick(DESTRUCTABLE, -0.5, -0.33, 0.2, 1, 1, 1)); // White brick
    bricks.push_back(Brick(DESTRUCTABLE, -0.5, 0.33, 0.2, 1, 0.5, 0)); // Orange brick
    bricks.push_back(Brick(DESTRUCTABLE, 0.5, -0.33, 0.2, 0.5, 0.5, 0.5)); // Grey brick
    bricks.push_back(Brick(DESTRUCTABLE, 0, 0, 0.2, 1, 0.5, 0.5)); // Red brick

    while (!glfwWindowShouldClose(window)) {
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        paddle.drawBrick();

        for (auto& brick : bricks) {
            brick.drawBrick();
        }

        // Check circle-circle collisions
        for (int i = 0; i < world.size(); i++) {
            for (int j = i + 1; j < world.size(); j++) {
                world[i].CheckCollision(world[j]);
            }

            // Check collisions with bricks
            for (auto& brick : bricks) {
                world[i].CheckCollision(&brick);
            }

            world[i].MoveOneStep();
            world[i].DrawCircle();
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    
