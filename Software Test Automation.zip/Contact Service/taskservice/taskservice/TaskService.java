package taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
private Map<String, Task> tasks;

public TaskService() {
	this.tasks = new HashMap<>();
}

public boolean addTask(Task task) {
String taskId = task.getTaskId();

if(!tasks.containsKey(taskId)) {
	tasks.put(taskId, task);
	return true;
} else {
return false;
}
}
public boolean deleteTask (String taskId) {
	return tasks.remove(taskId) != null;
}

public boolean updateTask(String taskId, String name, String description) {
	if (tasks.containsKey(taskId)) {
		Task task = tasks.get(taskId);
		if (name != null) {
			task.setName(name);
		}
		if (description != null) {
			task.setDescription(description);
		}
		return true;
	}
	return false;
}	
	public Iterable<Task>getTasks(){
		return tasks.values();
	}
}		

