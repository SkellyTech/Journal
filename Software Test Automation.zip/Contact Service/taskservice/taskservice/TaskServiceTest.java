package taskservice;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class TaskServiceTest {

	private TaskService taskService;
	
	@Before 
	public void setUp() {
		taskService = new TaskService();
	}
	
	@Test
	public void testAddTask() {
		Task task = new Task("334", "Henry", "Task for Henry");
		assertTrue(taskService.addTask(task));
	}
	@Test
	public void testAddDuplicateTask() {
		Task task1 = new Task("334", "Henry", "Task for Henry");
		Task task2 = new Task("334", "Henry", "Task for Henry");
		assertTrue(taskService.addTask(task1));
		assertFalse(taskService.addTask(task2));
	}
	@Test
	public void testDeleteTask() {
		Task task = new Task("334", "Henry", "Task for Henry");
		taskService.addTask(task);
		assertTrue(taskService.deleteTask("334"));
	}
	@Test
	public void testUpdateTask() {
		Task task = new Task("334", "Henry", "Task for Henry");
		taskService.addTask(task);
		
		assertTrue(taskService.updateTask("334", "UpdateHenry", "Updated task for Henry"));
		
		Task updateTask = taskService.getTasks().iterator().next();
		assertEquals("UpdateHenry", updateTask.getName());
		assertEquals("Updated task for Henry", updateTask.getDescription());
	}
	
	}
