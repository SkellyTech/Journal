package taskservice;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


public class TaskTest {

		private TaskService taskService;
		
		@Before
		public void setUp() {
			taskService = new TaskService();
		}
		
		@Test 
		public void testAddTask() {
			Task task = new Task("334", "Henry", "Task for Henry");
			assertTrue(taskService.addTask(task));
		}
		@Test
		public void testDeleteTask() {
			Task task = new Task("334", "Henry", "Task for Henry");
			taskService.addTask(task);
			assertTrue(taskService.deleteTask("334"));
		}
		
		@Test
		public void testUpdateTask() {
			Task task = new Task("334", "Henry", "Task for Henry");
			taskService.addTask(task);
			
			assertTrue(taskService.updateTask("334",  "UpdateHenry",  "Updated task for Henry"));
			
			Task updateTask = taskService.getTasks().iterator().next();
			assertEquals("UpdateHenry", updateTask.getName());
			assertEquals("Updated task for Henry", updateTask.getDescription());
		}

		@Test(expected = IllegalArgumentException.class)
		public void testInvalidTaskId() {
			Task task = new Task("12345678901", "ValidName", "ValidDescription");
		}
		
		@Test(expected = IllegalArgumentException.class)
		public void testInvalidName() {
			Task task = new Task("ValidId", "ThisNameIsWayTooLong", "ValidDescription");
		}
		
		@Test(expected = IllegalArgumentException.class)
		public void testInvalidDescription() {
			Task task = new Task("ValidId", "ValidName", "ThisDescriptionIsWayTooLong");
		}
		}

