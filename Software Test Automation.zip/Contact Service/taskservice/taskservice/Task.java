package taskservice;

public class Task {

	private static final int MAX_TASK_ID_LENGTH = 10;
	private static final int MAX_NAME_LENGTH = 20;
	private static final int MAX_DESCRIPTION_LENGTH = 50;
	
private String taskId;
private String name;
private String description;

	public Task (String taskId, String name, String description) {
		validateId(taskId);
		validateName(name);
		validateDescription(description);
		
		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}
	
	
	public String getTaskId() {
		return taskId;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		validateDescription(description);
		this.description = description;
	}
	
	public void setName(String name) {
		validateName(name);
		this.name = name;
	}
	
	private void validateId(String id) {
		if (!isValidId(id)) {
			throw new IllegalArgumentException("Invalid Task ID");
		}
	}
	private void validateName(String name) {
		if (!isValidName(name)) {
			throw new IllegalArgumentException("Invalid Name");
		}
	}
	
	private void validateDescription(String description) {
		if (!isValidDescription(description)) {
			throw new IllegalArgumentException("Invalid Description");
		}
	}
	private boolean isValidId(String id) {
		return id != null && id.length() <= MAX_TASK_ID_LENGTH;	
	}
	
	private boolean isValidName(String name) {
		return name != null && name.length() <= MAX_NAME_LENGTH;
	}
	
	private boolean isValidDescription(String description) {
		return description != null && description.length() <= MAX_DESCRIPTION_LENGTH;
	}
	
	@Override	
	public String toString() {
		return "Task{" +
				"taskId= '" + taskId + '\'' +
				", name='" + name + '\'' + 
				", description='" + description + '\'' + 
				'}';
	}
	
	}

