package ContactService;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContactTest {

	@Test
	public void testAddContact() {
		ContactService contactService = new ContactService();
		
		String contactId = "334";
		String firstName = "Henry";
		String lastName = "Nemon";
		String phone = "7753345000";
		String address = "323 Roadside Street";
		
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		
		boolean added = contactService.addContact(contact);
		
		assertTrue(added);
		assertEquals(contact, contactService.getContacts().iterator().next());
		
	}
	
	@Test
	public void testDeleteContact() {
		ContactService contactService = new ContactService();
		
		String contactId = "334";
		String firstName = "Henry";
		String lastName = "Nemon";
		String phone = "7753345000";
		String address = "323 Roadside Street";
		
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		
		contactService.addContact(contact);
		boolean deleted = contactService.deleteContact(contactId);
		
		assertTrue(deleted);
		
		assertFalse(contactService.getContacts().iterator().hasNext());
		
	}
	
	@Test
	public void testUpdateContact() {
		ContactService contactService = new ContactService();
		String contactId = "334";
		String firstName = "Henry";
		String lastName = "Nemon";
		String phone = "7753345000";
		String address = "323 Roadside Street";
		
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		contactService.addContact(contact); 
		boolean updated = contactService.updateContact(contactId, "John", "Thamos", "785-3325000", "323 Riverside Street");
		
		assertTrue(updated);
		
		Contact updatedContact = contactService.getContacts().iterator().next();
		
		assertEquals("John", updatedContact.getFirstName());
		assertEquals("Thamos", updatedContact.getLastName());
		assertEquals("7853325000", updatedContact.getPhone());
		assertEquals("323 Riverside Street", updatedContact.getAddress());
	}
	}

