package ContactService;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ContactServiceTest {
	@Before
	public void setUp() {
		new ContactService();
	}

	@Test
	public void testAddContact() {
		ContactService contactService = new ContactService();
		
		String contactId = "334";
		String firstName = "Henry";
		String lastName = "Nemon";
		String phone = "7753345000";
		String address = "323 Roadside Street";
		
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		
		boolean added = contactService.addContact(contact);
		
		assertTrue(added);
		assertEquals(contact, contactService.getContacts().iterator().next());
		
	}
	
	@Test
	public void testDeleteContact() {
		ContactService contactService = new ContactService();
		
		String contactId = "334";
		String firstName = "Henry";
		String lastName = "Nemon";
		String phone = "7753345000";
		String address = "323 Roadside Street";
		
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		
		contactService.addContact(contact);
		boolean deleted = contactService.deleteContact(contactId);
		
		assertTrue(deleted);
		assertFalse(contactService.getContacts().iterator().hasNext());
	}
	
	@Test
	public void testUpdateContact() {
		ContactService contactService = new ContactService();
		String contactId = "334";
		String firstName = "Henry";
		String lastName = "Nemon";
		String phone = "7753345000";
		String address = "323 Roadside Street";
		
		Contact contact = new Contact(contactId, firstName, lastName, phone, address);
		contactService.addContact(contact);
		
		boolean updated = contactService.updateContact(contactId, "John", "Thamos", "7853325000", "323 Riverside Street");
		
		assertTrue(updated);
		
		Contact updatedContact = contactService.getContacts().iterator().next();
		
		assertEquals("John", updatedContact.getFirstName());
		assertEquals("Thamos", updatedContact.getLastName());
		assertEquals("7853325000", updatedContact.getPhone());
		assertEquals("323 Riverside Street", updatedContact.getAddress());
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testContactIdNull() {
			new Contact(null, "John", "Thamos", "7853325000", "323 Riverside Street");
	}
	@Test(expected = IllegalArgumentException.class)
	public void testContactIdTooLong() {
			new Contact("12345678901123", "John", "Thamos", "7853325000", "323 Riverside Street");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testContactIdInvalidLength() {
		
		new Contact("345666536789", "John", "Thamos", "7853325000", "323 Riverside Street");
		new Contact("334567", "John", "Thamos", "7853325000", "Riverside Street");
	}
	@Test(expected = IllegalArgumentException.class) 
	public void testFirstNameNull() { 
		new Contact("334", null, "Thamos", "7853325000", "323 Riverside Street");
	}
	@Test(expected = IllegalArgumentException.class) 
	public void testLastNameNull() {
		new Contact("334", "John", null, "7853325000", "323 Riverside Street");
	}
	@Test(expected = IllegalArgumentException.class) 
	public void testLastNameTooLong() {
		new Contact("334", "John", "Thamonuslons", "7853325000", "323 Riverside Street");
	}
	
	@Test(expected = IllegalArgumentException.class) 
	public void testPhoneNull() {
		new Contact("334", "John", "Thamos", null, "323 Riverside Street");
	}
	@Test(expected = IllegalArgumentException.class) 
	public void testPhoneNotTenDigits() {
		new Contact("334", "John", "Thamos", "345-376", "323 Riverside Street");
	}
	@Test(expected = IllegalArgumentException.class) 
	public void testAddressNull() {
		new Contact("334", "John", "Thamos", "7853325000", null);
	}
	@Test(expected = IllegalArgumentException.class) 
	public void testAddressTooLong() {
		new Contact("334", "John", "Thamos", "7853325000", "12345678901234567890");
	}
	}