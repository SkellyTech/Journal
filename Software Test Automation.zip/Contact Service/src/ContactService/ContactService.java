package ContactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	private Map<String, Contact> contacts;
	
	public ContactService() {
		this.contacts = new HashMap<>();
	}
	public boolean addContact(Contact contact) {
		if (!contacts.containsKey(contact.getContactId())) {
			contacts.put(contact.getContactId(), contact);
			return true;
		}
		return false;
	}
	
	
public boolean deleteContact(String contactId) {
	if (contacts.containsKey(contactId)) {
		contacts.remove(contactId);
		return true;
	}
	return false;
}

public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
	if (contacts.containsKey(contactId)) {
		Contact contact = contacts.get(contactId);
		
		if (firstName !=null) {
			contact.setFirstName(firstName);
		}
		if (lastName !=null) {
			contact.setLastName(lastName);
		}
		if (phone !=null) {
			contact.setPhone(phone);
		}
		if (address !=null) {
			contact.setAddress(address);
		}
		return true;
	}
	return false;
}
	public Iterable<Contact> getContacts() {
		return contacts.values();
	}
	
	public Contact getContact(String contactId) {
		return contacts.get(contactId);
	}
	
	}

