import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class AppointmentServiceTest {

	@Test
	public void testAddAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("334", futureDate, "Henry's Appointment");
		appointmentService.addAppointment(appointment);
		
		assertEquals(1, appointmentService.getAppointments().size());
	}
	
	@Test
	public void testDeleteAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("334", futureDate, "Henry's Appointment");
		appointmentService.addAppointment(appointment);
		
		appointmentService.deleteAppointment("334");
		assertEquals(0, appointmentService.getAppointments().size());
	}
}
		