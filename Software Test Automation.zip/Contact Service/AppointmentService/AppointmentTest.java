import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;

public class AppointmentTest {

	@Test
	public void testAppointmentCreation() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("334", futureDate, "Henry's Appointment");
		
		assertEquals("334", appointment.getAppointmentId());
		assertEquals(futureDate, appointment.getAppointmentDate());
		assertEquals("Henry's Appointment", appointment.getDescription());
		
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidAppointmentId() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		new Appointment(null, futureDate, "Invalid ID");
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testInvalidAppointmentDate() {
		Date pastDate = new Date(System.currentTimeMillis() + 86400000);
		new Appointment("335", pastDate, "Invalid ID");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testInvalidDescription() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		new Appointment("336", futureDate, null);
	}
}
