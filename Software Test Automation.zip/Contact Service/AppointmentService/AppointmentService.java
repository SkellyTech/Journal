import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentService {
	
private List<Appointment> appointments;

public AppointmentService() {
	this.appointments = new ArrayList<>();
}

public void addAppointment(Appointment appointment) {
	if (!appointmentExists(appointment.getAppointmentId()));
	appointments.add(appointment);
}

public void deleteAppointment(String appointmentId) {
	appointments.removeIf(appointment -> appointment.getAppointmentId().equals(appointmentId));
	
}

public List<Appointment> getAppointments() {
	return appointments;
}

private boolean appointmentExists(String appointmentId) {
	for (Appointment appointment : appointments) {
		if (appointment.getAppointmentId().equals(appointmentId)) {
			return true;
		}
	}
	return false;
}
}
	